void main() {
  String str1 = 'this is an example of a single-line string';
  String str2 = "fluttwer";
  String str3 = """Asim""";

  var a = 10;
  var b = 20;

  print(str1);
  print(str2);
  print(str3);

  // We can add expression using the ${expression}.
  print("The sum is  = ${a + b}");
}
