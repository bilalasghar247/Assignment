void main() {  
  var heart_rune = '\u2665';  
  var theta_rune = '\u{1f600}';  
  print(heart_rune);  
  print(theta_rune);  
}  