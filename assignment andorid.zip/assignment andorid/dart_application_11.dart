void main() {  
  String str = 'JavaTpoint';  
  print("Welcome to JavaTpoint");  
  print(str.codeUnitAt(0));  
}  