void main() {
  print("Example - Remove Element in the given Set");
  var names = <String>{"Peter", "John", "Ricky", "Devansh", "Finch"};

  names.forEach((value) {
    print('Value:  $value');
  });
}
