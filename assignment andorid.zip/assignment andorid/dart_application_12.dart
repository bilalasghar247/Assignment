void main(){   
   "JavaTpoint".runes.forEach((int rune) {   
      var character=new String.fromCharCode(rune);   
      print(character);   
   });    
}  