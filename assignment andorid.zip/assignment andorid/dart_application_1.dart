void main() {
  String str1 = 'Hello ';
  String str2 = "World!";
  String str3 = str1 + str2;

  print(str3);

  var x = 26;
  var y = 10;

  print("The result is  = ${x % y}");

  var name = "Asim";
  var roll_nu = 81;

  print("My name is ${name}, my roll number is ${roll_nu}");
}
